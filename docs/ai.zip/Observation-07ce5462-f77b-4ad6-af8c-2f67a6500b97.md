# BR.GOV.SAUDE.BR-CORE.FHIR\07ce5462-f77b-4ad6-af8c-2f67a6500b97 - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **07ce5462-f77b-4ad6-af8c-2f67a6500b97**

## Example Observation: 07ce5462-f77b-4ad6-af8c-2f67a6500b97

| |
| :--- |
|  |

**status**: Final

**category**: Vital Signs

**code**: Blood Pressure

**subject**: [José da Silva](Patient-b2f63a4c-ddaa-4652-8481-ac1ff473104e.md)

**encounter**: [Ambulatorial](Encounter-c6d553d8-cce0-404b-9d1f-eeffbf7fc6df.md)

**effective**: 2025-01-13 08:30:00+0000

**issued**: 2025-01-13 08:35:00+0000

**performer**: [Maria Clara](Practitioner-d3b61455-f432-48f0-b83b-ba825922d735.md)

> **component****code**: Systolic blood pressure**value**: 120 mmHg (Detalhes: UCUM códigomm[Hg] = 'mm[Hg]')

> **component****code**: Diastolic blood pressure**value**: 80 mmHg (Detalhes: UCUM códigomm[Hg] = 'mm[Hg]')



## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "07ce5462-f77b-4ad6-af8c-2f67a6500b97",
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "vital-signs",
      "display" : "Vital Signs"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "85354-9",
      "display" : "Blood pressure panel with all children optional"
    }],
    "text" : "Blood Pressure"
  },
  "subject" : {
    "reference" : "Patient/b2f63a4c-ddaa-4652-8481-ac1ff473104e",
    "display" : "José da Silva"
  },
  "encounter" : {
    "reference" : "Encounter/c6d553d8-cce0-404b-9d1f-eeffbf7fc6df",
    "display" : "Ambulatorial"
  },
  "effectiveDateTime" : "2025-01-13T08:30:00Z",
  "issued" : "2025-01-13T08:35:00Z",
  "performer" : [{
    "reference" : "Practitioner/d3b61455-f432-48f0-b83b-ba825922d735",
    "display" : "Maria Clara"
  }],
  "component" : [{
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "8480-6",
        "display" : "BP sys"
      }],
      "text" : "Systolic blood pressure"
    },
    "valueQuantity" : {
      "value" : 120,
      "unit" : "mmHg",
      "system" : "http://unitsofmeasure.org",
      "code" : "mm[Hg]"
    }
  },
  {
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "8462-4",
        "display" : "BP dias"
      }],
      "text" : "Diastolic blood pressure"
    },
    "valueQuantity" : {
      "value" : 80,
      "unit" : "mmHg",
      "system" : "http://unitsofmeasure.org",
      "code" : "mm[Hg]"
    }
  }]
}

```
