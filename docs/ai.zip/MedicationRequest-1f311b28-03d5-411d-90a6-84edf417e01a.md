# BR.GOV.SAUDE.BR-CORE.FHIR\1f311b28-03d5-411d-90a6-84edf417e01a - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **1f311b28-03d5-411d-90a6-84edf417e01a**

## Example MedicationRequest: 1f311b28-03d5-411d-90a6-84edf417e01a

| |
| :--- |
|  |

Língua: pt-BR; 

**Aplicam-se regras especiais: http://example.org/rules!**

**identifier**: `http://hospital.example.org/medication-request`/12345

**status**: Active

**statusReason**: Suspeita de Intolerância

**intent**: Order

**doNotPerform**: false

**medication**: [levofloxacino](Medication-3a46210c-7eb3-48ec-aa67-db7e7ee18864.md)

**subject**: [João Carlos](Patient-b2f63a4c-ddaa-4652-8481-ac1ff473104e.md)

**encounter**: [Ambulatorial](Encounter-c6d553d8-cce0-404b-9d1f-eeffbf7fc6df.md)

**supportingInformation**: [Vital Signs](Observation-07ce5462-f77b-4ad6-af8c-2f67a6500b97.md)

**authoredOn**: 2024-06-18 14:00:00+0000

**requester**: [Maria Clara](Practitioner-d3b61455-f432-48f0-b83b-ba825922d735.md)

**performer**: [Maria Clara](Practitioner-d3b61455-f432-48f0-b83b-ba825922d735.md)

**performerType**: MEDICO DE FAMILIA E COMUNIDADE

**reasonCode**: Febre

> **dosageInstruction****sequence**: 1**text**: Tomar 1 comprimido a cada 6 horas por 5 dias.**timing**: 4 por 1 day**site**: Cavidade oral

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 500 mg |


> **dispenseRequest****validityPeriod**: 2024-06-18 14:00:00+0000 --> 2024-07-18 14:00:00+0000**numberOfRepeatsAllowed**: 1**quantity**: 20 comprimidos

### ExpectedSupplyDurations

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Value** | **Unit** | **System** |
| * | 5 | days | [http://unitsofmeasure.org](http://terminology.hl7.org/6.5.0/CodeSystem-v3-ucum.html) |

**performer**: [Hospital Sírio-Libanês](Organization-1428c345-c221-411f-880f-6fb163817387.md)

### Substitutions

| | | |
| :--- | :--- | :--- |
| - | **Allowed[x]** | **Reason** |
| * | true | alternativa terapêutica |



## Resource Content

```json
{
  "resourceType" : "MedicationRequest",
  "id" : "1f311b28-03d5-411d-90a6-84edf417e01a",
  "implicitRules" : "http://example.org/rules",
  "language" : "pt-BR",
  "identifier" : [{
    "system" : "http://hospital.example.org/medication-request",
    "value" : "12345"
  }],
  "status" : "active",
  "statusReason" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/medicationrequest-status-reason",
      "code" : "sintol",
      "display" : "Suspected Intolerance"
    }],
    "text" : "Suspeita de Intolerância"
  },
  "intent" : "order",
  "doNotPerform" : false,
  "medicationReference" : {
    "reference" : "Medication/3a46210c-7eb3-48ec-aa67-db7e7ee18864",
    "display" : "levofloxacino"
  },
  "subject" : {
    "reference" : "Patient/b2f63a4c-ddaa-4652-8481-ac1ff473104e",
    "display" : "João Carlos"
  },
  "encounter" : {
    "reference" : "Encounter/c6d553d8-cce0-404b-9d1f-eeffbf7fc6df",
    "display" : "Ambulatorial"
  },
  "supportingInformation" : [{
    "reference" : "Observation/07ce5462-f77b-4ad6-af8c-2f67a6500b97",
    "display" : "Vital Signs"
  }],
  "authoredOn" : "2024-06-18T14:00:00Z",
  "requester" : {
    "reference" : "Practitioner/d3b61455-f432-48f0-b83b-ba825922d735",
    "display" : "Maria Clara"
  },
  "performer" : {
    "reference" : "Practitioner/d3b61455-f432-48f0-b83b-ba825922d735",
    "display" : "Maria Clara"
  },
  "performerType" : {
    "coding" : [{
      "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRCBO",
      "code" : "225130",
      "display" : "MEDICO DE FAMILIA E COMUNIDADE"
    }]
  },
  "reasonCode" : [{
    "coding" : [{
      "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRCID10",
      "code" : "R50.8",
      "display" : "Outra febre especificada"
    }],
    "text" : "Febre"
  }],
  "dosageInstruction" : [{
    "sequence" : 1,
    "text" : "Tomar 1 comprimido a cada 6 horas por 5 dias.",
    "timing" : {
      "repeat" : {
        "frequency" : 4,
        "period" : 1,
        "periodUnit" : "d"
      }
    },
    "site" : {
      "coding" : [{
        "system" : "http://snomed.info/sct",
        "code" : "74262004"
      }],
      "text" : "Cavidade oral"
    },
    "doseAndRate" : [{
      "doseQuantity" : {
        "value" : 500,
        "unit" : "mg"
      }
    }]
  }],
  "dispenseRequest" : {
    "validityPeriod" : {
      "start" : "2024-06-18T14:00:00Z",
      "end" : "2024-07-18T14:00:00Z"
    },
    "numberOfRepeatsAllowed" : 1,
    "quantity" : {
      "value" : 20,
      "unit" : "comprimidos"
    },
    "expectedSupplyDuration" : {
      "value" : 5,
      "unit" : "days",
      "system" : "http://unitsofmeasure.org"
    },
    "performer" : {
      "reference" : "Organization/1428c345-c221-411f-880f-6fb163817387",
      "display" : "Hospital Sírio-Libanês"
    }
  },
  "substitution" : {
    "allowedBoolean" : true,
    "reason" : {
      "coding" : [{
        "system" : "http://terminology.hl7.org/CodeSystem/v3-ActReason",
        "code" : "CT",
        "display" : "continuing therapy"
      }],
      "text" : "alternativa terapêutica"
    }
  }
}

```
