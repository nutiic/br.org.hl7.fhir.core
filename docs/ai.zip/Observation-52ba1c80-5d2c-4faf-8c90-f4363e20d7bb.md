# BR.GOV.SAUDE.BR-CORE.FHIR\Exemplo de observação. - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **Exemplo de observação.**

## Example Observation: Exemplo de observação.

| |
| :--- |
|  |

**status**: Final

**category**: Laboratory

**code**: Colesterol total e frações

**subject**: [José da Silva](Patient-b2f63a4c-ddaa-4652-8481-ac1ff473104e.md)

**encounter**: [Ambulatorial](Encounter-c6d553d8-cce0-404b-9d1f-eeffbf7fc6df.md)

**effective**: 2025-01-13 08:00:00+0000

**issued**: 2025-01-13 08:30:00+0000

**performer**: 

* [Maria Clara](Practitioner-d3b61455-f432-48f0-b83b-ba825922d735.md)
* [Hospital Sírio-Libanês](Organization-1428c345-c221-411f-880f-6fb163817387.md)

**note**: 

> 

Paciente orientado para seguir com dieta saudável e exercícios para gerenciar colesterol


> **component****code**: Colesterol Total**value**: 190 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL')

### ReferenceRanges

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Low** | **High** | **Text** |
| * | 125 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL') | 200 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL') | Normal |


> **component****code**: LDL Cholesterol**value**: 130 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL')

### ReferenceRanges

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Low** | **High** | **Text** |
| * | 0 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL') | 100 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL') | Normal |


> **component****code**: HDL Cholesterol**value**: 45 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL')

### ReferenceRanges

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Low** | **High** | **Text** |
| * | 40 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL') | 60 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL') | Normal |


> **component****code**: Triglycerides**value**: 150 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL')

### ReferenceRanges

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Low** | **High** | **Text** |
| * | 0 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL') | 150 mg/dL (Detalhes: UCUM códigomg/dL = 'mg/dL') | Normal |




## Resource Content

```json
{
  "resourceType" : "Observation",
  "id" : "52ba1c80-5d2c-4faf-8c90-f4363e20d7bb",
  "status" : "final",
  "category" : [{
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/observation-category",
      "code" : "laboratory",
      "display" : "Laboratory"
    }]
  }],
  "code" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "24331-1",
      "display" : "Lipid 1996 Pnl SerPl"
    }],
    "text" : "Colesterol total e frações"
  },
  "subject" : {
    "reference" : "Patient/b2f63a4c-ddaa-4652-8481-ac1ff473104e",
    "display" : "José da Silva"
  },
  "encounter" : {
    "reference" : "Encounter/c6d553d8-cce0-404b-9d1f-eeffbf7fc6df",
    "display" : "Ambulatorial"
  },
  "effectiveDateTime" : "2025-01-13T08:00:00Z",
  "issued" : "2025-01-13T08:30:00Z",
  "performer" : [{
    "reference" : "Practitioner/d3b61455-f432-48f0-b83b-ba825922d735",
    "display" : "Maria Clara"
  },
  {
    "reference" : "Organization/1428c345-c221-411f-880f-6fb163817387",
    "display" : "Hospital Sírio-Libanês"
  }],
  "note" : [{
    "text" : "Paciente orientado para seguir com dieta saudável e exercícios para gerenciar colesterol"
  }],
  "component" : [{
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "2093-3",
        "display" : "Colest SerPl-mCnc"
      }],
      "text" : "Colesterol Total"
    },
    "valueQuantity" : {
      "value" : 190,
      "unit" : "mg/dL",
      "system" : "http://unitsofmeasure.org",
      "code" : "mg/dL"
    },
    "referenceRange" : [{
      "low" : {
        "value" : 125,
        "unit" : "mg/dL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "high" : {
        "value" : 200,
        "unit" : "mg/dL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "text" : "Normal"
    }]
  },
  {
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "13457-7",
        "display" : "LDLc SerPl Calc-mCnc"
      }],
      "text" : "LDL Cholesterol"
    },
    "valueQuantity" : {
      "value" : 130,
      "unit" : "mg/dL",
      "system" : "http://unitsofmeasure.org",
      "code" : "mg/dL"
    },
    "referenceRange" : [{
      "low" : {
        "value" : 0,
        "unit" : "mg/dL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "high" : {
        "value" : 100,
        "unit" : "mg/dL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "text" : "Normal"
    }]
  },
  {
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "2085-9",
        "display" : "HDLc SerPl-mCnc"
      }],
      "text" : "HDL Cholesterol"
    },
    "valueQuantity" : {
      "value" : 45,
      "unit" : "mg/dL",
      "system" : "http://unitsofmeasure.org",
      "code" : "mg/dL"
    },
    "referenceRange" : [{
      "low" : {
        "value" : 40,
        "unit" : "mg/dL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "high" : {
        "value" : 60,
        "unit" : "mg/dL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "text" : "Normal"
    }]
  },
  {
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "2571-8",
        "display" : "Trigl SerPl-mCnc"
      }],
      "text" : "Triglycerides"
    },
    "valueQuantity" : {
      "value" : 150,
      "unit" : "mg/dL",
      "system" : "http://unitsofmeasure.org",
      "code" : "mg/dL"
    },
    "referenceRange" : [{
      "low" : {
        "value" : 0,
        "unit" : "mg/dL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "high" : {
        "value" : 150,
        "unit" : "mg/dL",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg/dL"
      },
      "text" : "Normal"
    }]
  }]
}

```
