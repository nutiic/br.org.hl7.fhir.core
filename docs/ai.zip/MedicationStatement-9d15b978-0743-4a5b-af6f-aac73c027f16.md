# BR.GOV.SAUDE.BR-CORE.FHIR\Exemplo de declaração de medicação. - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **Exemplo de declaração de medicação.**

## Example MedicationStatement: Exemplo de declaração de medicação.

| |
| :--- |
|  |

**status**: Active

**category**: Uso ambulatorial

**medication**: [levofloxacino](Medication-3a46210c-7eb3-48ec-aa67-db7e7ee18864.md)

**subject**: [João Carlos](Patient-b2f63a4c-ddaa-4652-8481-ac1ff473104e.md)

**effective**: 2024-12-01 --> 2024-12-10

**dateAsserted**: 2024-12-01

**informationSource**: [Maria Clara](Practitioner-d3b61455-f432-48f0-b83b-ba825922d735.md)

**reasonCode**: Acute pharyngitis, unspecified

**note**: 

> 

Paciente relatou sintomas de dor de garganta há 3 dias.


> **dosage****text**: Tomar 1 cápsula via oral a cada 8 horas por 7 dias.**timing**: Código , 3 por 1 day**route**: Oral use

### DoseAndRates

| | |
| :--- | :--- |
| - | **Dose[x]** |
| * | 500 mg (Detalhes: UCUM códigomg = 'mg') |




## Resource Content

```json
{
  "resourceType" : "MedicationStatement",
  "id" : "9d15b978-0743-4a5b-af6f-aac73c027f16",
  "status" : "active",
  "category" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/medication-statement-category",
      "code" : "outpatient",
      "display" : "Outpatient"
    }],
    "text" : "Uso ambulatorial"
  },
  "medicationReference" : {
    "reference" : "Medication/3a46210c-7eb3-48ec-aa67-db7e7ee18864",
    "display" : "levofloxacino"
  },
  "subject" : {
    "reference" : "Patient/b2f63a4c-ddaa-4652-8481-ac1ff473104e",
    "display" : "João Carlos"
  },
  "effectivePeriod" : {
    "start" : "2024-12-01",
    "end" : "2024-12-10"
  },
  "dateAsserted" : "2024-12-01",
  "informationSource" : {
    "reference" : "Practitioner/d3b61455-f432-48f0-b83b-ba825922d735",
    "display" : "Maria Clara"
  },
  "reasonCode" : [{
    "coding" : [{
      "system" : "http://hl7.org/fhir/sid/icd-10",
      "code" : "J02.9",
      "display" : "Acute pharyngitis, unspecified"
    }]
  }],
  "note" : [{
    "text" : "Paciente relatou sintomas de dor de garganta há 3 dias."
  }],
  "dosage" : [{
    "text" : "Tomar 1 cápsula via oral a cada 8 horas por 7 dias.",
    "timing" : {
      "repeat" : {
        "frequency" : 3,
        "period" : 1,
        "periodUnit" : "d"
      },
      "code" : {
        "coding" : [{
          "system" : "http://terminology.hl7.org/CodeSystem/v3-GTSAbbreviation",
          "code" : "TID",
          "display" : "TID"
        }]
      }
    },
    "route" : {
      "coding" : [{
        "system" : "http://standardterms.edqm.eu",
        "code" : "20053000",
        "display" : "Oral use"
      }]
    },
    "doseAndRate" : [{
      "doseQuantity" : {
        "value" : 500,
        "unit" : "mg",
        "system" : "http://unitsofmeasure.org",
        "code" : "mg"
      }
    }]
  }]
}

```
