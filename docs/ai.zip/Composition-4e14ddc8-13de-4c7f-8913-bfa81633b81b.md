# BR.GOV.SAUDE.BR-CORE.FHIR\Sumário de Alta Hospitalar - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **Sumário de Alta Hospitalar**

## Example Composition: Sumário de Alta Hospitalar

| |
| :--- |
|  |

**status**: Final

**type**: Sumário de Alta Hospitalar

**encounter**: [Ambulatorial](Encounter-c6d553d8-cce0-404b-9d1f-eeffbf7fc6df.md)

**date**: 2024-12-19

**author**: [Maria Clara](Practitioner-d3b61455-f432-48f0-b83b-ba825922d735.md)

**title**: Sumário de Alta Hospitalar



## Resource Content

```json
{
  "resourceType" : "Composition",
  "id" : "4e14ddc8-13de-4c7f-8913-bfa81633b81b",
  "status" : "final",
  "type" : {
    "coding" : [{
      "system" : "http://loinc.org",
      "code" : "18842-5",
      "display" : "Discharge sum"
    }],
    "text" : "Sumário de Alta Hospitalar"
  },
  "subject" : {
    "reference" : "Patient/b2f63a4c-ddaa-4652-8481-ac1ff473104e",
    "display" : "João Carlos Silva"
  },
  "encounter" : {
    "reference" : "Encounter/c6d553d8-cce0-404b-9d1f-eeffbf7fc6df",
    "display" : "Ambulatorial"
  },
  "date" : "2024-12-19",
  "author" : [{
    "reference" : "Practitioner/d3b61455-f432-48f0-b83b-ba825922d735",
    "display" : "Maria Clara"
  }],
  "title" : "Sumário de Alta Hospitalar",
  "section" : [{
    "id" : "diagnosticosAdmissao",
    "title" : "Diagnósticos da Admissão",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "42347-5",
        "display" : "Admission diagnosis (narrative)"
      }],
      "text" : "Diagnóstico na Internação"
    },
    "author" : [{
      "reference" : "Practitioner/d3b61455-f432-48f0-b83b-ba825922d735",
      "display" : "Maria Clara"
    }],
    "focus" : {
      "reference" : "Condition/91d8d24f-a70d-4ebf-8dea-71cf92ce1bd5",
      "display" : "Dispnéia"
    },
    "mode" : "snapshot",
    "entry" : [{
      "reference" : "Condition/91d8d24f-a70d-4ebf-8dea-71cf92ce1bd5",
      "display" : "Dispnéia"
    }]
  },
  {
    "title" : "Procedimentos Realizados",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "47519-4",
        "display" : "Procedures Hx Doc"
      }],
      "text" : "Histórico de Procedimentos"
    },
    "author" : [{
      "reference" : "Practitioner/d3b61455-f432-48f0-b83b-ba825922d735",
      "display" : "Maria Clara"
    }],
    "focus" : {
      "reference" : "Procedure/b0030c23-bd7d-445e-bfe5-020828f7dbaf",
      "display" : "Consulta médica em atenção primária"
    },
    "entry" : [{
      "reference" : "Procedure/b0030c23-bd7d-445e-bfe5-020828f7dbaf",
      "display" : "Consulta médica em atenção primária"
    }]
  },
  {
    "title" : "Prescrição da Alta",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "8654-6",
        "display" : "Hospital Discharge Medications"
      }],
      "text" : "Medicamentos na Alta"
    },
    "author" : [{
      "reference" : "Practitioner/d3b61455-f432-48f0-b83b-ba825922d735",
      "display" : "Maria Clara"
    }],
    "focus" : {
      "reference" : "MedicationRequest/1f311b28-03d5-411d-90a6-84edf417e01a",
      "display" : "Paracetamol"
    },
    "entry" : [{
      "reference" : "MedicationRequest/1f311b28-03d5-411d-90a6-84edf417e01a",
      "display" : "Paracetamol"
    }]
  },
  {
    "title" : "Plano de Cuidados",
    "code" : {
      "coding" : [{
        "system" : "http://loinc.org",
        "code" : "18776-5",
        "display" : "Plan of care note"
      }],
      "text" : "Plano de Cuidados"
    },
    "author" : [{
      "reference" : "Practitioner/d3b61455-f432-48f0-b83b-ba825922d735",
      "display" : "Maria Clara"
    }],
    "focus" : {
      "reference" : "CarePlan/1ed343f2-5231-40d6-a6ea-4428105b7532",
      "display" : "Plano de Cuidados para Asma Persistente Moderada"
    },
    "entry" : [{
      "reference" : "CarePlan/1ed343f2-5231-40d6-a6ea-4428105b7532",
      "display" : "Plano de Cuidados para Asma Persistente Moderada"
    }]
  }]
}

```
