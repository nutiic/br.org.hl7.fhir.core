# BR.GOV.SAUDE.BR-CORE.FHIR\Exemplo de alergia e intolerância. - FHIR v4.0.1

* [**Table of Contents**](toc.md)
* [**Lista de artefatos**](artifacts.md)
* **Exemplo de alergia e intolerância.**

## Example AllergyIntolerance: Exemplo de alergia e intolerância.

| |
| :--- |
|  |

Língua: pt-BR

**clinicalStatus**: Active

**verificationStatus**: Confirmed

**type**: Allergy

**category**: Medication

**criticality**: High Risk

**code**: Alergia a lidocaína

**patient**: [João Carlos Silva](Patient-b2f63a4c-ddaa-4652-8481-ac1ff473104e.md)

### Reactions

| | | | | |
| :--- | :--- | :--- | :--- | :--- |
| - | **Substance** | **Manifestation** | **Severity** | **ExposureRoute** |
| * | LIDOCAÍNA, CLORIDRATO + CLORETO DE BENZALCÔNIO 20 + 1,3 MG/ML SPRAY TÓPICO 50 ML | Angioedema | Severe | Intravenosa |



## Resource Content

```json
{
  "resourceType" : "AllergyIntolerance",
  "id" : "b2549739-2479-406e-ab6e-1e4251b08bc9",
  "language" : "pt-BR",
  "clinicalStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-clinical",
      "code" : "active",
      "display" : "Active"
    }]
  },
  "verificationStatus" : {
    "coding" : [{
      "system" : "http://terminology.hl7.org/CodeSystem/allergyintolerance-verification",
      "code" : "confirmed",
      "display" : "Confirmed"
    }]
  },
  "type" : "allergy",
  "category" : ["medication"],
  "criticality" : "high",
  "code" : {
    "coding" : [{
      "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRMedicamento",
      "code" : "BR0299656",
      "display" : "LIDOCAÍNA, CLORIDRATO + CLORETO DE BENZALCÔNIO 20 + 1,3 MG/ML SPRAY TÓPICO 50 ML"
    }],
    "text" : "Alergia a lidocaína"
  },
  "patient" : {
    "reference" : "Patient/b2f63a4c-ddaa-4652-8481-ac1ff473104e",
    "display" : "João Carlos Silva"
  },
  "reaction" : [{
    "substance" : {
      "coding" : [{
        "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRMedicamento",
        "code" : "BR0299656",
        "display" : "LIDOCAÍNA, CLORIDRATO + CLORETO DE BENZALCÔNIO 20 + 1,3 MG/ML SPRAY TÓPICO 50 ML"
      }],
      "text" : "LIDOCAÍNA, CLORIDRATO + CLORETO DE BENZALCÔNIO 20 + 1,3 MG/ML SPRAY TÓPICO 50 ML"
    },
    "manifestation" : [{
      "coding" : [{
        "system" : "https://terminologia.saude.gov.br/fhir/CodeSystem/BRMedDRA",
        "code" : "10002424",
        "display" : "angioedema"
      }],
      "text" : "Angioedema"
    }],
    "severity" : "severe",
    "exposureRoute" : {
      "coding" : [{
        "system" : "http://standardterms.edqm.eu",
        "code" : "20045000",
        "display" : "Intravenous use"
      }],
      "text" : "Intravenosa"
    }
  }]
}

```
